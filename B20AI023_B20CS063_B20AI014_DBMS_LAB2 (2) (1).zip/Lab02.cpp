
#include <iostream>
#include <windows.h>
#include <mysql.h>
#include<algorithm>
#include<chrono>

using namespace std;

MYSQL *conn;


void display(){
    MYSQL_RES *result=mysql_store_result(conn);
    MYSQL_ROW row;
    //display attribute names
    for(int i=0;i<mysql_num_fields(result);i++){
        cout<<mysql_fetch_field_direct(result,i)->name<<" ";
    }
    cout<<endl;
    while((row=mysql_fetch_row(result))){
        for(int i=0;i<mysql_num_fields(result);i++){
            cout<<row[i]<<" ";
        }
        cout<<endl;
    }
}

void display_status(int current_status){
    if (current_status==0){
        cout<<"Query Sucessful"<<endl;
    }
    else {
        cout<<"Error: "<<mysql_error(conn)<<endl;
        exit(1);
    }
}

void displayA(){
    int query_status=mysql_query(conn,"SELECT * FROM sales;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}

void displayB(){
    int query_status=mysql_query(conn,"SELECT * FROM sales WHERE name='abc';");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void displayC(){
    int query_status=mysql_query(conn,"SELECT commission FROM sales WHERE address_city='Mumbai' OR 'Chennai';");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void displayD(){
    int query_status=mysql_query(conn,"SELECT salesman_id,name FROM sales WHERE address_city=coverage_city;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void displayE(){
    int query_status=mysql_query(conn,"SELECT salesman_id,name FROM sales WHERE address_city=coverage_city;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}

void displayF(){
    int query_status=mysql_query(conn,"SELECT MAX(commission) FROM sales;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}

void displayG(){
    int query_status=mysql_query(conn,"SELECT coverage_city, MAX(commission) FROM sales;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void displayH(){
    int query_status=mysql_query(conn,"SELECT AVG(commission) FROM sales ORDER by coverage_city;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void displayI(){
    int query_status=mysql_query(conn,"SELECT coverage_city FROM sales GROUP BY commission HAVING count(*)=1;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void displayJ(){
    int query_status=mysql_query(conn,"SELECT DISTINCT commission FROM sales As a WHERE Exists ( SELECT 1 FROM sales As b WHERE b.commission = a.commission And b.coverage_city != a.coverage_city );");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void displayK(){
    int query_status=mysql_query(conn,"SELECT * FROM sales As a WHERE Exists ( SELECT 1 FROM sales As b WHERE b.name = a.name And b.coverage_city != a.coverage_city );");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void displayL(){
    int query_status=mysql_query(conn,"ALTER TABLE sales ADD date_of_employment date, ADD date_of_release date;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}

void display3ca(){
    int query_status=mysql_query(conn,"SELECT * FROM `sales` WHERE date_of_release IS NULL;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void display3cb(){
    int query_status=mysql_query(conn,"SELECT * FROM `sales` WHERE date_of_release IS NOT NULL;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void display3cc(){
    int query_status=mysql_query(conn,"SELECT * FROM sales ORDER BY date_of_employment;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void display3cd(){
    int query_status=mysql_query(conn,"SELECT COUNT(salesman_id) FROM sales WHERE     YEAR(date_of_employment) = 2022;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void display3ce(){
    int query_status=mysql_query(conn,"SELECT YEAR(date_of_employment), COUNT(*) AS MAX FROM sales     GROUP BY YEAR(date_of_employment) ORDER BY MAX DESC;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}
void display3cf(){
    int query_status=mysql_query(conn,"SELECT YEAR(date_of_release), COUNT(*) AS MAX FROM sales GROUP BY YEAR(date_of_release) ORDER BY `MAX` ASC");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}


void dairy_table(){
    mysql_query(conn, "DROP TABLE IF EXISTS dairy;");
    int query_status=mysql_query(conn, "CREATE TABLE IF NOT EXISTS dairy(id int not NULL PRIMARY KEY, price int, buying_date Date, name varchar(255), quantity int, expiry Date, admin_id int, FOREIGN KEY(admin_id) REFERENCES admin(admin_id));");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        int insert_status=mysql_query(conn, "INSERT INTO dairy VALUES(1, 150, '2022-08-08', 'Milk', 10, '2022-02-12', 1);");
        display_status(insert_status);
        insert_status=mysql_query(conn, "INSERT INTO dairy VALUES(2, 100, '2022-11-08', 'Cheese', 10, '2022-12-14', 2);");
        display_status(insert_status);
        insert_status=mysql_query(conn, "INSERT INTO dairy VALUES(3, 10, '2022-05-08', 'Yogurt', 10, '2022-06-10', 3);");
        display_status(insert_status);
    }
}


void split_dairy(){
    mysql_query(conn, "DROP TABLE IF EXISTS dairy_bcnf_R1;");
    mysql_query(conn, "DROP TABLE IF EXISTS dairy_bcnf_R2;");

    int query_status=mysql_query(conn, "CREATE TABLE dairy_bcnf_R1(id int, price int, name varchar(255));");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        int split_status=mysql_query(conn, "INSERT INTO dairy_bcnf_R1 SELECT id, price, name FROM dairy;");
        if(split_status){
            cout<<"Error : "<<mysql_error(conn)<<endl;
            exit(1);
        }
        else{
            cout<<"dairy split successfull"<<'\n';
        }
        query_status=mysql_query(conn, "CREATE TABLE dairy_bcnf_R2(id int, admin_id int, quantity int, buying_date Date, expiry Date,FOREIGN KEY (admin_id) REFERENCES admin(admin_id));");
        if(query_status){
            cout<<"Error : "<<mysql_error(conn)<<endl;
            exit(1);
        }
        else{
            int split_status=mysql_query(conn, "INSERT INTO dairy_bcnf_R2 SELECT id, admin_id, quantity, buying_date, expiry FROM dairy;");
            if(split_status){
                cout<<"Error : "<<mysql_error(conn)<<endl;
                exit(1);
            }
            else{
                cout<<"dairy split successfull"<<'\n';
            }
        }
    }
}


void display_4_C_A_Original(){
    int query_status=mysql_query(conn, "SELECT name, id, quantity, buying_date, best_before FROM fruits WHERE buying_date = (SELECT MIN(buying_date) FROM fruits);");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

    query_status=mysql_query(conn, "SELECT name, id, quantity, buying_date, expiry FROM dairy WHERE buying_date = (SELECT MIN(buying_date) FROM dairy);");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

    query_status=mysql_query(conn, "SELECT name, id, weight, buying_date, expiry FROM meat WHERE buying_date = (SELECT MIN(buying_date) FROM meat);");

    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

    query_status=mysql_query(conn, "SELECT name, id, quantity, buying_date, best_before FROM vegetables WHERE buying_date = (SELECT MIN(buying_date) FROM vegetables);");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

}

void display_4_C_B(int month){
    //display details of groceries that were purchased in month of August
    int query_status=mysql_query(conn, ("SELECT fruits_bcnf_R1.name, fruits_bcnf_R1.id, fruits_bcnf_R2.quantity, fruits_bcnf_R2.buying_date, fruits_bcnf_R2.best_before FROM fruits_bcnf_R1 INNER JOIN fruits_bcnf_R2 ON fruits_bcnf_R1.id=fruits_bcnf_R2.id WHERE MONTH(buying_date) = " + to_string(month) + ";").c_str());
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

    query_status=mysql_query(conn, ("SELECT dairy_bcnf_R1.name, dairy_bcnf_R1.id, dairy_bcnf_R2.quantity, dairy_bcnf_R2.buying_date, dairy_bcnf_R2.expiry FROM dairy_bcnf_R1 INNER JOIN dairy_bcnf_R2 ON dairy_bcnf_R1.id=dairy_bcnf_R2.id WHERE MONTH(buying_date) = " + to_string(month) + ";").c_str());
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

    query_status=mysql_query(conn, "SELECT meat_bcnf_R1.name, meat_bcnf_R1.id, meat_bcnf_R2.weight, meat_bcnf_R2.buying_date, meat_bcnf_R2.expiry FROM meat_bcnf_R1 INNER JOIN meat_bcnf_R2 ON meat_bcnf_R1.id=meat_bcnf_R2.id WHERE MONTH(buying_date) = 8;");
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

    query_status=mysql_query(conn, ("SELECT vegetables_bcnf_R1.name, vegetables_bcnf_R1.id, vegetables_bcnf_R2.quantity, vegetables_bcnf_R2.buying_date, vegetables_bcnf_R2.best_before FROM vegetables_bcnf_R1 INNER JOIN vegetables_bcnf_R2 ON vegetables_bcnf_R1.id=vegetables_bcnf_R2.id WHERE MONTH(buying_date) = " + to_string(month) + ";").c_str());

    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }


}


void display_4_C_B_Original(int month){
    int query_status=mysql_query(conn, ("SELECT name, id, quantity, buying_date, best_before FROM fruits WHERE MONTH(buying_date) = " + to_string(month) + ";").c_str());
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

    query_status=mysql_query(conn, ("SELECT name, id, quantity, buying_date, expiry FROM dairy WHERE MONTH(buying_date) = " + to_string(month) + ";").c_str());
    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

    query_status=mysql_query(conn, ("SELECT name, id, weight, buying_date, expiry FROM meat WHERE MONTH(buying_date) = " + to_string(month) + ";").c_str());

    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }

    query_status=mysql_query(conn, ("SELECT name, id, quantity, buying_date, best_before FROM vegetables WHERE MONTH(buying_date) = " + to_string(month) + ";").c_str());

    if(query_status){
        cout<<"Error : "<<mysql_error(conn)<<endl;
        exit(1);
    }
    else{
        display();
    }
}


int main()
{
    conn = mysql_init(NULL);
    if (conn == NULL) {
        cout<<"Error: "<<mysql_error(conn)<<endl;
        exit(1);
    }

    // mysql_real_connect(Connection Instance, Username, Password, Database, Port, Unix Socket, Client Flag)
    if (mysql_real_connect(conn, "localhost", "sawan", "password", "lab_02", 3306, NULL, 0)) {
        cout<<"Connected Successfully!"<<endl;
       ;
        char query[256];
        cout<<"A"<<endl;
        displayA();
        cout<<"B"<<endl;
        displayB();
        cout<<"C"<<endl;
        displayC();
        cout<<"D"<<endl;
        displayD();
        cout<<"E"<<endl;
        displayE();
        cout<<"F"<<endl;
        displayF(); 
        cout<<"G"<<endl;
        displayG();
        cout<<"H"<<endl;
        displayH();
        cout<<"I"<<endl;
        displayI();
        cout<<"J"<<endl;
        displayJ();
        cout<<"J"<<endl;
        cout<<"K"<<endl;

        displayK();
        cout<<"L"<<endl;

        displayL();

        cout<<"3ca"<<endl;
        display3ca();
        cout<<"3cb"<<endl;
        display3cb();
        cout<<"3cc"<<endl;
        display3cc();
        cout<<"3cd"<<endl;
        display3cd();
        cout<<"3ce"<<endl;
        display3ce();
        cout<<"3cf"<<endl;
        display3cf();

        cout<<"4"<<endl;
        dairy_table();
        cout<<"Normalization"<<endl;
        split_dairy();
        
        display_4_C_A_Original();
        display_4_C_B(5);
        display_4_C_B_Original(5);

        

        

    }
        return 0;

}